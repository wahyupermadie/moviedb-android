package com.example.moviedb.utils

interface ViewMessage{
    fun showError(message : String)
}