package com.example.moviedb.koin

val appComponent = listOf(networkModule, appModule)